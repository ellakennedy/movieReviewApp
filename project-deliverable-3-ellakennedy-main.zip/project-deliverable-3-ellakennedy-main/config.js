let config = {
  host    : 'ec2-18-216-101-119.us-east-2.compute.amazonaws.com',
  user    : 'em3kenne',
  password: 'MSCI245',
  database: 'em3kenne'
};
 
export default config;
